﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeManagerApp
{
    public partial class MainWindow : Window
    {
        private readonly RecipeManager recipeManager;

        public MainWindow()
        {
            InitializeComponent();
            recipeManager = new RecipeManager();
            recipeManager.CaloriesExceeded += Message => MessageBox.Show(Message);
            InitializeFoodGroupComboBox();
        }

        private void InitializeFoodGroupComboBox()
        {
            List<string> foodGroups = Enum.GetNames(typeof(FoodGroup)).ToList();
            FoodGroupComboBox.ItemsSource = foodGroups;
        }

        private void NewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text.Trim();
            if (!string.IsNullOrEmpty(recipeName))
            {
                recipeManager.EnterNewRecipe(recipeName);
                RecipeNameTextBox.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Please enter a recipe name.");
            }
        }

        private void DisplayRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeListBox.ItemsSource = recipeManager.GetRecipes().Select(r => r.Name).ToList();
        }

        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string selectedRecipe = RecipeListBox.SelectedItem as string;
            if (selectedRecipe != null)
            {
                recipeManager.DisplayRecipe(selectedRecipe);
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.ClearData();
            RecipeListBox.ItemsSource = null;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            if (FoodGroupComboBox.SelectedItem != null && Enum.TryParse(FoodGroupComboBox.SelectedItem.ToString(), true, out FoodGroup selectedFoodGroup))
            {
                List<Recipe> filteredRecipes = recipeManager.FilterRecipesByFoodGroup(selectedFoodGroup);
                RecipeListBox.ItemsSource = filteredRecipes.Select(r => r.Name).ToList();
            }
            else
            {
                MessageBox.Show("Please select a valid food group to filter recipes.");
            }
        }
    }
}
