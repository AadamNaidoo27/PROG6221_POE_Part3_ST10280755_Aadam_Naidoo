﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeManagerApp
{
    public class RecipeManager
    {
        private List<Recipe> recipes;

        public event Action<string> CaloriesExceeded;

        public RecipeManager()
        {
            recipes = new List<Recipe>();
        }

        public void EnterNewRecipe(string name)
        {
            Recipe newRecipe = new Recipe(name);
            recipes.Add(newRecipe);
        }

        public void DisplayRecipes()
        {
            foreach (var recipe in recipes)
            {
                recipe.PrintRecipe();
                Console.WriteLine();
            }
        }

        public void DisplayRecipe(string recipeName)
        {
            Recipe recipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
            if (recipe != null)
            {
                recipe.PrintRecipe();
            }
            else
            {
                Console.WriteLine($"Recipe '{recipeName}' not found.");
            }
        }

        public void ClearData()
        {
            recipes.Clear();
        }

        public List<Recipe> GetRecipes()
        {
            return recipes;
        }

        public List<Recipe> FilterRecipesByFoodGroup(FoodGroup foodGroup)
        {
            return recipes.Where(r => r.IngredientList.Any(i => i.FoodGroup == foodGroup)).ToList();
        }

        private void SortRecipesByName()
        {
            recipes = recipes.OrderBy(r => r.Name).ToList();
        }
    }
}
