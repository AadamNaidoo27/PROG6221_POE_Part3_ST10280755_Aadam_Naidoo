﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace PROG6221_POE_Part3_ST10280755_Aadam_Naidoo
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            // Initialize your application here

            // Optionally, you can handle any unhandled exceptions globally
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            this.DispatcherUnhandledException += App_DispatcherUnhandledException;
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // Handle any unhandled exceptions at the application level
            MessageBox.Show($"An unhandled exception occurred: {e.ExceptionObject}");
            // Optionally, you can log the exception details here
        }

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            // Handle any unhandled exceptions on the UI thread
            e.Handled = true; // Set to true to prevent application from crashing
            MessageBox.Show($"An unhandled UI exception occurred: {e.Exception}");
            // Optionally, you can log the exception details here
        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);
            // Clean up or save any application-wide resources or settings
        }
    }
}
