﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeManagerApp
{
    public enum FoodGroup
    {
        Protein,
        Vegetable,
        Fruit,
        Grain,
        Dairy
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public FoodGroup FoodGroup { get; set; }
    }

    public class Recipe
    {
        public string Name { get; }
        public List<Ingredient> IngredientList { get; }
        private List<string> stepsList;

        public Recipe(string name)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            IngredientList = new List<Ingredient>();
            stepsList = new List<string>();
        }

        public void AddIngredient(string ingredientName, double quantity, string unit, double calories, FoodGroup foodGroup)
        {
            if (ingredientName == null)
            {
                throw new ArgumentNullException(nameof(ingredientName));
            }

            Ingredient ingredient = new Ingredient
            {
                Name = ingredientName,
                Quantity = quantity,
                Unit = unit,
                Calories = calories,
                FoodGroup = foodGroup
            };

            IngredientList.Add(ingredient);
        }

        public void AddStep(string stepDescription)
        {
            if (stepDescription == null)
            {
                throw new ArgumentNullException(nameof(stepDescription));
            }

            stepsList.Add(stepDescription);
        }

        public double TotalCalories => IngredientList.Sum(i => i.Calories);

        public bool ExceedsCalories(double threshold) => TotalCalories > threshold;

        public void PrintRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in IngredientList)
            {
                Console.WriteLine($"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < stepsList.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {stepsList[i]}");
            }
            Console.WriteLine($"Total Calories: {TotalCalories}");
        }
    }
}
